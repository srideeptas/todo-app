import { TodoEntry } from './todo';

describe('TodoEntry', () => {
  it('should create an instance', () => {
    expect(new TodoEntry()).toBeTruthy();
  });
});